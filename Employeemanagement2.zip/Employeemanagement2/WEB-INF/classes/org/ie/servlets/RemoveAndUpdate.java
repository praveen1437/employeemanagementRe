package org.ie.servlets;


import org.ie.dao.JdbcEmployeeLoginCheck;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

public class RemoveAndUpdate extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
        PrintWriter printWriter;
        JdbcEmployeeLoginCheck jdbcEmployeeLoginCheck;
        int employeeId;
        String employeeUsername;
        boolean isValid = false;
        RequestDispatcher requestDispatcher = null;
        //set Content type
        res.setContentType("text/html");
        //get printwriter object
        printWriter = res.getWriter();
        HttpSession session;
        //get session object and check authorization
        session=req.getSession();
        if( session.getAttribute("managerUserName")!=null) {
            //get employeeid and user name from form
            if (req.getParameter("eId").equals("") || req.getParameter("EmployeeUserName").equals("")) {
                if (req.getParameter("removeorupdate").equals("Remove Employee")) {
                    System.out.println("in remove html");
                    printWriter.println("<h1>Invalid Credentials</h1>");
                    requestDispatcher = req.getRequestDispatcher("/remove.html");
                    requestDispatcher.include(req, res);
                } else {
                    printWriter.println("<h1>Invalid Credentials</h1>");
                    System.out.println("in update html");
                    requestDispatcher = req.getRequestDispatcher("/update.html");
                    requestDispatcher.include(req, res);
                }
            }
            employeeId = Integer.parseInt(req.getParameter("eId"));
            employeeUsername = req.getParameter("EmployeeUserName");
            //get jdbc login check object to validate inputs came from form
            jdbcEmployeeLoginCheck = (JdbcEmployeeLoginCheck) getServletContext().getAttribute("loginCheck");
            try {
                isValid = jdbcEmployeeLoginCheck.checkIDAndUserName(employeeId, employeeUsername);
                System.out.println("below isvalid in remove and update");
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            if (isValid) {
                req.setAttribute("username", employeeUsername);
                System.out.println("is valid if");
                if (req.getParameter("removeorupdate").equals("Remove Employee")) {
                    System.out.println("is valid if and inside remove if");
                    requestDispatcher = req.getRequestDispatcher("removeemployee");
                    requestDispatcher.forward(req, res);
                } else {
                    System.out.println("is valid if and inside remove else");
                    requestDispatcher = req.getRequestDispatcher("updateemployee");
                    requestDispatcher.forward(req, res);
                }
            } else {
                System.out.println("is valid else");
                if (req.getParameter("removeorupdate").equals("Remove Employee")) {
                    System.out.println("is valid else and inside remove if");
                    System.out.println("in remove html");
                    printWriter.println("<h1>Invalid Credentials</h1>");
                    requestDispatcher = req.getRequestDispatcher("/remove.html");
                    requestDispatcher.include(req, res);
                } else {
                    System.out.println("is valid else and inside remove else");
                    printWriter.println("<h1>Invalid Credentials</h1>");
                    System.out.println("in update html");
                    requestDispatcher = req.getRequestDispatcher("/update.html");
                    requestDispatcher.include(req, res);
                }
            }

        }
        else{
            printWriter.println("<h1>you are not authorized to perform this operation");
        }
    }
}
