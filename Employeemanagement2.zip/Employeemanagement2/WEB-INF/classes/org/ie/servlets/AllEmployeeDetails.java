package org.ie.servlets;

import org.ie.dto.EmployeeDto;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class AllEmployeeDetails extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        PrintWriter printWriter;
        ResultSet resultSet;
        List<EmployeeDto> employeeDtoList = new ArrayList<>();
        printWriter = res.getWriter();
        HttpSession session;
        //get session object and check authorization
        session = req.getSession();
        if (session.getAttribute("managerUserName") != null) {
            res.setContentType("text/html");
            printWriter.println("<h1>Employees in our organization");
            printWriter.println("<table>");
            for (EmployeeDto employeeDto : employeeDtoList
            ) {
                printWriter.println("<tr>");
                printWriter.println("<td>" + employeeDto.getId() + "</td>");
                printWriter.println("<td>" + employeeDto.getEmployeeName() + "</td>");
                printWriter.println("<td>  employeeDto.getAddress()) </td>");
                printWriter.println("<td>employeeDto.getDesignation())</td>");
                printWriter.println("</tr>");
            }

        } else {
         printWriter.println("<h1> you are not authorized to perform this operation</h1>");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
       doGet(req,res);
    }
}
