package org.ie.dao;

import org.ie.dto.EmployeeDto;

import java.sql.*;

public class JdbcInsertEmployee {
    private final static String INSERT_QUERY = "INSERT INTO EMPDETAILS (PERSONID,NAME,ADDRESS,DESIGNATION,USERNAME,PASSWORD) VALUES(?,?,?,?,?,?)";
    private final static String USER_CHECK = "SELECT USERNAME FROM EMPDETAILS WHERE USERNAME=?";

    public boolean insertData(EmployeeDto dto) throws SQLException, ClassNotFoundException {
        PreparedStatement ps1, ps2;
        ResultSet rs;
        int count = 0;
        //createConnection
        Class.forName("com.mysql.jdbc.Driver");
        //try(Connection con=DriverManager.getConnection("","","")){
        try (Connection con = DriverManager.getConnection("jdbc:mysql://iedevdb.cju8h0qbqt75.ap-south-1.rds.amazonaws.com:3306/training", "dbadmin", "dbadmin123")) {
            //prepare statemnt object creation
            ps1 = con.prepareStatement(USER_CHECK);
            //execute the query
            ps1.setString(1,dto.getUserName());
            rs = ps1.executeQuery();
            String username = "notfound";
            //process the result for username checking
            while (rs.next()) {
                username = rs.getString(1);
            }
            if (!username.equals("notfound")) {
                throw new IllegalArgumentException("user name  already exits please choose another one");
            }
            //add new user to the database
            ps2 = con.prepareStatement(INSERT_QUERY);
            ps2.setInt(1, dto.getId());
            ps2.setString(2, dto.getEmployeeName());
            ps2.setString(3, dto.getAddress());
            ps2.setString(4, dto.getDesignation());
            ps2.setString(5, dto.getUserName());
            ps2.setString(6, dto.getPassWord());
            count = ps2.executeUpdate();
            System.out.println(count);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return count != 0;
    }
}
