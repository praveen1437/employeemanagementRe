package org.ie.dao;


import org.ie.dto.EmployeeDto;

import java.sql.*;

/**
 * update employee details in the data base
 */
public class JdbcUpdateEmployee {
    private static final String UPDATE_QUERY="UPDATE EMPDETAILS SET NAME=? ,ADDRESS=?,DESIGNATION=? WHERE USERNAME=?";
    public  boolean updateEmployeeDetails(EmployeeDto old,EmployeeDto update) throws ClassNotFoundException, SQLException {
        PreparedStatement preparedStatement;
        ResultSet resultSet;
        Connection connection=null;
        int count;
        //loads the driver class for mysql data base
        Class.forName("com.mysql.jdbc.Driver");
        //creates connection object
        connection = DriverManager.getConnection("jdbc:mysql://iedevdb.cju8h0qbqt75.ap-south-1.rds.amazonaws.com:3306/training", "dbadmin", "dbadmin123");
        preparedStatement=connection.prepareStatement(UPDATE_QUERY);
        //set query parameters
        preparedStatement.setString(1,update.getEmployeeName());
        preparedStatement.setString(2,update.getAddress());
        preparedStatement.setString(3,update.getDesignation());
        preparedStatement.setString(4,old.getUserName());
        //execute the update query
      count=  preparedStatement.executeUpdate();


        return count!=0;
    }

   /* public static void main(String[] args) throws SQLException, ClassNotFoundException {
        EmployeeDto old= new EmployeeDto();
        EmployeeDto update= new EmployeeDto();
        old.setUserName("srinath123");
        update.setDesignation("SR DEV");
        update.setEmployeeName("SRI");
        update.setAddress("UPPAL");
        boolean b=updateEmployeeDetails(old,update);
        System.out.println(b);
    }*/

}
