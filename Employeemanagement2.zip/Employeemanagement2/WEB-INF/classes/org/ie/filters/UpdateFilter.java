package org.ie.filters;

import javax.servlet.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;

public class UpdateFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpSession session=((HttpServletRequest)servletRequest).getSession();
        if(session.getAttribute("managerUserName")!=null){
            filterChain.doFilter(servletRequest,servletResponse);
        }
        else{
            RequestDispatcher requestDispatcher=servletRequest.getRequestDispatcher("UpdateForm.html");
        }
    }

    @Override
    public void destroy() {

    }
}
