package org.ie.servlets;

import org.ie.dao.JdbcEmployeeLoginCheck;
import org.ie.dao.JdbcEmployeeRemove;
import org.ie.dao.JdbcFetchEmployeeDetails;
import org.ie.dao.JdbcUpdateEmployee;
import org.ie.dto.EmployeeDto;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

/**
 * servlet to process the update request
 */
public class UpdateEmployee extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        PrintWriter pw;
        int employeeId;
        String employeeUserName;
        JdbcUpdateEmployee jdbcUpdateEmployee;
        JdbcEmployeeLoginCheck jdbcEmployeeLoginCheck;
        RequestDispatcher requestDispatcher;
        HttpSession session=req.getSession();
        boolean isPresent=false;
        boolean updateResult=false;
        //create printwriter object to display content on the browser
        pw = res.getWriter();
        //set content type to browser
        res.setContentType("text/html");
        //get the values from update.html
        employeeId = Integer.parseInt(req.getParameter("eId"));
        employeeUserName = req.getParameter("EmployeeUserName");
        //get  jdbc login check object from context object
        jdbcEmployeeLoginCheck= (JdbcEmployeeLoginCheck) getServletContext().getAttribute("loginCheck");
        //check whether the given id and username is correct or not
        try {
           isPresent= jdbcEmployeeLoginCheck.checkIDAndUserName(employeeId,employeeUserName);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }catch (IllegalArgumentException e){
            pw.println("<h1>Wrong user name or password</h1>");
            requestDispatcher = req.getRequestDispatcher("/updateemployee");
            requestDispatcher.include(req,res);
        }
        if (!isPresent){
            pw.println("<h1>Wrong user name or password</h1>");
           pw.println("<a href=home.html>Home</a>");
        }
        else {
            System.out.println(employeeUserName+""+ "from update employee class");
            session.setAttribute("username",employeeUserName);
            res.sendRedirect("UpdateForm.html");
        }

        pw.println("<a href=home.html>HOME</a>");

    }
}
