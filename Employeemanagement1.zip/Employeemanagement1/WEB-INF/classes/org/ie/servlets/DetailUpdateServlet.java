package org.ie.servlets;

import org.ie.dao.JdbcFetchEmployeeDetails;
import org.ie.dao.JdbcUpdateEmployee;
import org.ie.dto.EmployeeDto;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

public class DetailUpdateServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        PrintWriter pw;
       pw= res.getWriter();
        res.setContentType("text/html");
        JdbcUpdateEmployee jdbcUpdateEmployee = (JdbcUpdateEmployee) getServletContext().getAttribute("update");
        boolean updateResult=false;

            //get servlet context object and get jdbcemployee fetch object
            JdbcFetchEmployeeDetails jdbcFetchEmployeeDetails= (JdbcFetchEmployeeDetails) getServletContext().getAttribute("fetchEmployeeDetails");
            EmployeeDto employeeDto=null;
            try {
                //get employee object which is present in data base
                employeeDto= jdbcFetchEmployeeDetails.fetchEmpDetail((String) req.getSession().getAttribute("username"));
                System.out.println((String)req.getSession().getAttribute("username"));
                System.out.println(employeeDto.getUserName());
                // get the values from update form
                String name= req.getParameter("sname");
                System.out.println(name);
                String address= req.getParameter("sAddress");
                System.out.println(address);
                String designation= req.getParameter("sDesignation");
                System.out.println(designation);
                EmployeeDto updateDto= new EmployeeDto();
                updateDto.setEmployeeName(name);
                updateDto.setDesignation(designation);
                updateDto.setAddress(address);
                updateResult=jdbcUpdateEmployee.updateEmployeeDetails(employeeDto,updateDto);
            } catch (SQLException | ClassNotFoundException e) {
                e.printStackTrace();
            }


       if(updateResult){
        pw.println("<h1> record updated Successfully</h1>");
        pw.println("<a href=home.html>Home</a>");
    }
       else{
           pw.println("<h1>updation failed</h1>");
           pw.println("<a href=home.html>Home</a>");
       }
    }
}
